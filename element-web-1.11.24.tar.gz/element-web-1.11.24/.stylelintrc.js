module.exports = {
    ...require("matrix-react-sdk/.stylelintrc.js"),
    extends: ["stylelint-config-standard", "stylelint-config-prettier"],
};
