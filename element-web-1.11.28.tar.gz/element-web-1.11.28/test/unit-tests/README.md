Any UTs for vector-web layer components or functionality should go here.
This used to contain the UTs for notifications before they got moved to react-sdk.
